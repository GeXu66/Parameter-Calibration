% mcc -W python:test_fmincon ./test_fmincon.m
mcc -W lib:test_fmincon -T link:lib test_fmincon.m