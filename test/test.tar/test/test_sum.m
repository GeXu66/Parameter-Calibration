function sum = test_sum(a,b)
    sum = a+b;
    disp(['sum is ' num2str(sum)])
end